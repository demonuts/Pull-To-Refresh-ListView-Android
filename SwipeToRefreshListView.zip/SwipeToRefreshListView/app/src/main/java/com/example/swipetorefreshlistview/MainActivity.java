package com.example.swipetorefreshlistview;

import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ListView lv;
    private ListAdapter customeAdapter;
    private ArrayList<MyModel> imageModelArrayList;
    private int currentList = 0;
    private String[] firstList = new String[]{"Benz", "Bike",
            "Car","Carrera"
            ,"Ferrari","Harly",
            "Lamborghini","Silver"};
    private String[] secondList = new String[]{"Roger", "Rafael",
            "Novak","Maria"
            ,"Serena","Andy",
            "Agasi","Tsitsipas"};
    private String[] thirddList = new String[]{"India", "USA",
            "Canada","Australia"
            ,"Singapore","Japan",
            "UK","France"};
    private SwipeRefreshLayout mSwipeRefreshLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lv = (ListView) findViewById(R.id.lv);
        mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeToRefresh);

        imageModelArrayList = populateList(currentList);
        customeAdapter = new ListAdapter(this,imageModelArrayList);
        lv.setAdapter(customeAdapter);

        mSwipeRefreshLayout.setColorSchemeResources(R.color.colorAccent);
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if(currentList == 2){
                    currentList = -1 ;
                }
                currentList = currentList + 1;
                imageModelArrayList = populateList(currentList);
                customeAdapter = new ListAdapter(MainActivity.this,imageModelArrayList);
                lv.setAdapter(customeAdapter);
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });

    }

    private ArrayList<MyModel> populateList(int number){

        ArrayList<MyModel> list = new ArrayList<>();

        for(int i = 0; i < 8; i++){
            MyModel imageModel = new MyModel();
            if(number == 0) {
                imageModel.setName(firstList[i]);
            }else if (number == 1){
                imageModel.setName(secondList[i]);
            }else if (number == 2){
                imageModel.setName(thirddList[i]);
            }
            list.add(imageModel);
        }

        return list;

    }
}
